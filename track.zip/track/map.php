<?php
session_start();
$registeredPet = isset($_SESSION["registeredPet"]) ? $_SESSION["registeredPet"] : null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Leaflet Map with Clickable Markers, Geofencing, and Search</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.3/dist/leaflet.css" integrity="sha256-kLaT2GOSpHechhsozzB+flnD+zUyjE2LlfWPgU04xyI=" crossorigin="" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@opencage/leaflet-opencage-geosearch/leaflet-opencage-geosearch.css" />
    <style>
        #map {
            height: 900px;
        }

        /* Style for the return to dashboard button */
        .back {
            position: absolute;
            bottom: 10px;
            right: 20px;
            padding: 10px 20px;
            background-color: black;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            font-size: 25px;
        }
    </style>
</head>
<body>
    <div id="map"></div>

    <!-- Leaflet JS -->
    <script src="https://unpkg.com/leaflet@1.9.3/dist/leaflet.js" integrity="sha256-WBkoXOwTeyKclOHuWtc+i2uENFpDZ9YPdf5Hf+D7ewM=" crossorigin=""></script>
    <!-- OpenCage Geosearch JS -->
    <script src="https://cdn.jsdelivr.net/npm/@opencage/geosearch-bundle"></script>
    <script src="https://cdn.jsdelivr.net/npm/@opencage/leaflet-opencage-geosearch"></script>
    <script>
        var map = L.map('map').setView([51.505, -0.09], 13);

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 19
        }).addTo(map);

        var ownerMarker = null;
        var ownerGeofence = null;
        var geofenceRadius = 20; // radius in meters
        var petMarkers = [];

        function updateLocation(position) {
            var lat = position.coords.latitude;
            var lng = position.coords.longitude;

            if (ownerMarker) {
                ownerMarker.setLatLng([lat, lng]);
                if (ownerGeofence) {
                    ownerGeofence.setLatLng([lat, lng]);
                }
            } else {
                ownerMarker = L.marker([lat, lng]).addTo(map)
                    .bindPopup('Owner').openPopup();

                ownerGeofence = L.circle([lat, lng], {
                    radius: geofenceRadius,
                    color: 'red',
                    fillColor: '#f03',
                    fillOpacity: 0.5
                }).addTo(map);

            }

            map.setView([lat, lng], 13);
        }

        function handleLocationError(error) {
            alert('Error: ' + error.message);
        }

        if (navigator.geolocation) {
            navigator.geolocation.watchPosition(updateLocation, handleLocationError, {
                enableHighAccuracy: true,
                timeout: 5000,
                maximumAge: 0
            });
        } else {
            alert('Geolocation is not supported by your browser.');
        }

        function addMarker(lat, lng, name) {
            var marker = L.marker([lat, lng]).addTo(map)
                .bindPopup(name);

            var pet = {
                marker: marker,
            };
            petMarkers.push(pet);
        }

        function isInsideGeofence(lat, lng) {
            if (!ownerMarker) {
                return false;
            }
            var distance = map.distance(ownerMarker.getLatLng(), L.latLng(lat, lng));
            return distance <= geofenceRadius;
        }

        function isPetRegistered() {
            return <?php echo json_encode($registeredPet !== null); ?>;
        }

        function getRegisteredPetName() {
            return <?php echo json_encode($registeredPet ? $registeredPet["petName"] : ""); ?>;
        }

        map.on('click', function(e) {
            if (!isPetRegistered()) {
                alert('Please register a pet before adding markers.');
                window.location.href = 'pet-registration.php';
                return;
            }

            var lat = e.latlng.lat;
            var lng = e.latlng.lng;

            if (isInsideGeofence(lat, lng)) {
                var name = prompt('Enter marker name:');
                var registeredPetName = getRegisteredPetName();
                if (name && name === registeredPetName) {
                    addMarker(lat, lng, name);
                } else {
                    alert('Invalid pet name. Please enter the registered pet name.');
                }
            } else {
                alert('Marker must be placed within the geofence.');
            }
        });
    </script>
    <!-- Button to return to dashboard -->
    <a href="MainDashboard.php" class="back">Return to Dashboard</a>
</body>
</html>
