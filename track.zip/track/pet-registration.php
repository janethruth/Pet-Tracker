<?php
session_start();

if (!isset($_SESSION["registeredPets"])) {
    $_SESSION["registeredPets"] = [];
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $newPet = [
        "petName" => $_POST["petName"],
        "petAge" => $_POST["petAge"],
        "ownerName" => $_POST["ownerName"]
    ];

    $_SESSION["registeredPets"][] = $newPet;
    $_SESSION["registeredPet"] = $newPet;

    header("Location: map.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Pet Registration</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        form {
            max-width: 400px;
            margin: 0 auto;
        }
        label {
            display: block;
            margin-bottom: 8px;
        }
        input[type="text"], input[type="number"] {
            width: 100%;
            padding: 8px;
            margin-bottom: 12px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
        .registered-pets {
            margin-top: 20px;
        }
        .registered-pets h2 {
            font-size: 20px;
            margin-bottom: 10px;
        }
        .registered-pets ul {
            list-style-type: none;
            padding: 0;
        }
        .registered-pets li {
            margin-bottom: 5px;
            padding: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
    </style>
</head>
<body>
    <h1>Pet Registration</h1>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
        <label for="petName">Pet Name:</label>
        <input type="text" id="petName" name="petName" required>

        <label for="petAge">Pet Age:</label>
        <input type="number" id="petAge" name="petAge" required>

        <label for="ownerName">Owner Name:</label>
        <input type="text" id="ownerName" name="ownerName" required>

        <input type="submit" value="Register Pet">
    </form>

    <div class="registered-pets">
        <h2>Registered Pets</h2>
        <ul>
            <?php
            if (isset($_SESSION["registeredPets"])) {
                foreach ($_SESSION["registeredPets"] as $pet) {
                    echo "<li><strong>Name:</strong> " . htmlspecialchars($pet["petName"]) . ", <strong>Age:</strong> " . htmlspecialchars($pet["petAge"]) . ", <strong>Owner:</strong> " . htmlspecialchars($pet["ownerName"]) . "</li>";
                }
            }
            ?>
        </ul>
    </div>
</body>
</html>
