<?php
session_start();
include('./config/db_connection.php');


if (isset($_SESSION['success'])) {
    echo "<div class='alert' id='success-message' style='padding: 20px; margin-bottom: 20px; color: #3c763d; background-color: #dff0d8; border: 1px solid #d6e9c6; border-radius: 4px;'>";
    echo $_SESSION['success'];
    echo "</div>";
    unset($_SESSION['success']);
}

if (isset($_SESSION['error'])) {
    echo "<div class='alert' id='error-message' style='padding: 20px; margin-bottom: 20px; color: black; background-color: #FF6868; border: 1px solid #DCFFB7; border-radius: 4px;'>";
    echo $_SESSION['error'];
    echo "</div>";
    unset($_SESSION['error']);
}
if (isset($_SESSION['logout_success'])) {
    echo "<div class='alert' id='logout-message' style='padding: 20px; margin-bottom: 20px; color: #3c763d; background-color: #dff0d8; border: 1px solid #d6e9c6; border-radius: 4px;'>";
    echo $_SESSION['logout_success'];
    echo "</div>";
    unset($_SESSION['logout_success']);
}
?>

<!DOCTYPE html>
<html lang="en">
<style>

.header{

  position: absolute;
  top: 100px;
  left: 600px;
  font-size: 100px;
  font-weight: 500;
    }

.login{
    background-color: black;
    color: white;
    border-radius: 40px;
    position: absolute;
    left: 700px;
    top: 500px;
    padding: 5px 40px 5px 40px;
    font-size: 25px;
}

.signup{
    background-color: black;
    color: white;
    border-radius: 40px;
    position: absolute;
    left: 880px;
    top: 500px;
    padding: 5px 40px 5px 40px;
    font-size: 25px;
}


.bg{
width: 1710px;
height: 1000px;

}

.footer {
         background-color: black;
         color: #fff;
         padding: 20px;
         text-align: center;
         position: fixed;
         bottom: 0;
         width: 100%;
   
      }
      
      .footer a {
         color: #fff;
         text-decoration: none;
         padding: 0 10px;
      }
      
      .footer a:hover {
         text-decoration: underline;
      }

</style>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/output.css">
    <link rel="stylesheet" href="./css/styles.css">
    <title>Login</title>



<body>

<h1 class="header">Pet Tracking</h1>

<a href="./user/login.php" class="login">Log In</a>
<a href="./user/register.php" class="signup">Sign Up</a>

<img class="bg" src="./images/bg.jpg" width="1710px" height="600px">

<footer class="footer">
      <p>&copy; 2024 Pet Tracking App. All rights reserved.</p>
   </footer>

</body>
<script src="./javascript/sessionmessage.js"></script>

</html>

