<?php
session_start();
include('../config/db_connection.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Prepare SQL statement to fetch user data based on username
    $sql = "SELECT * FROM tblUsers WHERE Username = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "s", $username);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($result && $user = mysqli_fetch_assoc($result)) {
        // Verify the password
        if ($password === $user['Password']) { // Compare plain text passwords
            // Login successful. Store the UserID.
            $_SESSION['UserID'] = $user['UserID'];
            $_SESSION['success'] = 'You have successfully logged in!';
            header('Location: ../MainDashboard.php');
            exit;
        } else {
            // Invalid password
            $_SESSION['error'] = 'Invalid username or password';
            header('Location: ../MainDashboard.php');
            exit;
        }
    } else {
        // Invalid username
        $_SESSION['error'] = 'Invalid username or password';
        header('Location: ../MainDashboard.php');
        exit;
    }
} else {
    // Redirect if not a POST request (optional)
    header('Location: ../index.php');
    exit;
}
?>
