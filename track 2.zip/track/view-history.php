<?php
session_start();

// Function to delete a history entry based on timestamp
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_timestamp'])) {
    $deleteTimestamp = $_POST['delete_timestamp'];
    if (isset($_SESSION['history'])) {
        foreach ($_SESSION['history'] as $key => $entry) {
            if ($entry['timestamp'] === $deleteTimestamp) {
                unset($_SESSION['history'][$key]);
                break; // Exit loop once entry is deleted
            }
        }
        // Re-index the array after deletion
        $_SESSION['history'] = array_values($_SESSION['history']);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Location History</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        .back {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background-color: black;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 18px;
        }
        .delete-btn {
            background-color: #f44336;
            color: white;
            border: none;
            padding: 6px 12px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            cursor: pointer;
            border-radius: 3px;
        }
    </style>
</head>
<body>
    <h1>Location History</h1>
    <table>
        <thead>
            <tr>
                <th>Latitude</th>
                <th>Longitude</th>
                <th>Pet Name</th>
                <th>Address</th>
                <th>Date & Time</th>
                <th>Action</th> <!-- New column for delete button -->
            </tr>
        </thead>
        <tbody>
            <?php
            if (isset($_SESSION['history'])) {
                foreach ($_SESSION['history'] as $entry) {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($entry['lat']) . "</td>";
                    echo "<td>" . htmlspecialchars($entry['lng']) . "</td>";
                    echo "<td>" . htmlspecialchars($entry['name']) . "</td>";
                    echo "<td>" . htmlspecialchars($entry['address']) . "</td>";
                    echo "<td>" . htmlspecialchars($entry['timestamp']) . "</td>";
                    echo "<td><form method='post'><input type='hidden' name='delete_timestamp' value='" . htmlspecialchars($entry['timestamp']) . "'><button type='submit' class='delete-btn'>Delete</button></form></td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='6'>No history available</td></tr>";
            }
            ?>
        </tbody>
    </table>
    <!-- Button to return to dashboard -->
    <a href="MainDashboard.php" class="back">Return to Dashboard</a>
</body>
</html>
