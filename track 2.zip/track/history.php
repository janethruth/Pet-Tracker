\<?php
session_start();

// Check if POST request to add marker to history
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $lat = $_POST['lat'];
    $lng = $_POST['lng'];
    $name = $_POST['name'];
    $timestamp = $_POST['timestamp'];

    // Geocoding to get the exact location address (using OpenCage API)
    $apiKey = 'efb3bdb1602f47daa33b17492c45defe'; // Replace with your geocoding API key
    $url = "https://api.opencagedata.com/geocode/v1/json?q=$lat+$lng&key=$apiKey";
    $response = file_get_contents($url);
    $data = json_decode($response, true);
    $address = isset($data['results'][0]['formatted']) ? $data['results'][0]['formatted'] : 'Address not found';

    // Format timestamp to Philippine standard time (PST) and international standard date
    $timestamp = date('Y-m-d H:i:s', strtotime($timestamp)); // Convert timestamp to PHP DateTime format

    // Store in session history
    if (!isset($_SESSION['history'])) {
        $_SESSION['history'] = [];
    }

    $_SESSION['history'][] = [
        'lat' => $lat,
        'lng' => $lng,
        'name' => $name,
        'address' => $address,
        'timestamp' => $timestamp
    ];

    echo 'History saved.';
    // Redirect to avoid re-posting on page refresh
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit;
}

// Check if GET request to clear history
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['clear']) && $_GET['clear'] == true) {
    $_SESSION['history'] = []; // Clear history array
    echo 'History cleared.';
    // Redirect to avoid re-clearing on page refresh
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit;
}

// Check if GET request to delete a specific history item
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $deleteIndex = $_GET['delete'];
    if (isset($_SESSION['history'][$deleteIndex])) {
        unset($_SESSION['history'][$deleteIndex]);
        // Reindex the array after deletion
        $_SESSION['history'] = array_values($_SESSION['history']);
        echo 'History item deleted.';
        // Redirect to avoid re-deleting on page refresh
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Marker History</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        table, th, td {
            border: 1px solid #ccc;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        .clear-btn {
            display: inline-block;
            padding: 10px 20px;
            background-color: #f44336;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            font-size: 16px;
            margin-bottom: 10px;
        }
        .delete-btn {
            padding: 5px 10px;
            background-color: #f44336;
            color: white;
            border: none;
            border-radius: 3px;
            cursor: pointer;
            text-decoration: none; /* Ensure it looks like a button */
        }
    </style>
</head>
<body>
    <h1>Marker History</h1>
    
    <!-- Clear history button -->
    <a href="?clear=true" class="clear-btn" onclick="return confirm('Are you sure you want to clear all history?')">Clear History</a>

    <!-- Display history table -->
    <?php if (!empty($_SESSION['history'])): ?>
        <table>
            <thead>
                <tr>
                    <th>Latitude</th>
                    <th>Longitude</th>
                    <th>Name</th>
                    <th>Address</th>
                    <th>Timestamp (Philippine Standard Time)</th>
                    <th>Timestamp (International Standard Date)</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($_SESSION['history'] as $index => $marker): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($marker['lat']); ?></td>
                        <td><?php echo htmlspecialchars($marker['lng']); ?></td>
                        <td><?php echo htmlspecialchars($marker['name']); ?></td>
                        <td><?php echo htmlspecialchars($marker['address']); ?></td>
                        <td><?php echo htmlspecialchars(date('Y-m-d H:i:s', strtotime($marker['timestamp'] . ' UTC'))); ?></td>
                        <td><?php echo htmlspecialchars($marker['timestamp']); ?></td>
                        <td>
                            <form method="get" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                                <input type="hidden" name="delete" value="<?php echo $index; ?>">
                                <button type="submit" class="delete-btn" onclick="return confirm('Are you sure you want to delete this item?')">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No markers in history.</p>
    <?php endif; ?>
</body>
</html>
