<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Notes</title>
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary bg-gradient">
        <a class="navbar-brand" href="#">Simple Notes</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
                </li>
            </ul>
            <form class="form-inline my-2 my-lg-0">
                <input id="searchTxt" class="form-control mr-sm-2 rounded-pill" type="search" placeholder="Search notes here..."
                    aria-label="Search">
            </form>
        </div>
    </nav>
    <div class="container my-3">
        <h2 class="text-center">Notes</h2>
        <div class="card shadow-sm rounded-0">
            <div class="card-body">
                <h5 class="card-title">Create New Note</h5>
                <div class="form-group">
                    <input type="hidden" name="key" value="">
                    <textarea id="addTxt" class="form-control rounded-0" rows="3"></textarea>
                </div>
                <div class="text-center">
                    <button id="addBtn" class="btn btn-primary rounded-0">Add Note</button>
                    <button id="cancelBtn" class="btn btn-secindary rounded-0 border">Cancel</button>
                </div>
            </div>
        </div>
        <hr>
        <h2 class="text-center">Notes List</h2>
        <hr>
        <div id="notes" class="row container-fluid m-2">
        </div>
    </div>
    <!----------JAVASCRIPT--------->
    <script src="js/jquery.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/app.js"></script>
</body>

</html>