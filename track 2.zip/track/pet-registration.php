<?php
session_start();

// Initialize or get existing registered pets array from session
$registeredPets = isset($_SESSION["registeredPets"]) ? $_SESSION["registeredPets"] : [];

// Process registration form
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if delete request
    if (isset($_POST["deleteIndex"]) && is_numeric($_POST["deleteIndex"])) {
        $deleteIndex = $_POST["deleteIndex"];
        // Check if index exists
        if (isset($registeredPets[$deleteIndex])) {
            // Remove pet at specified index
            unset($registeredPets[$deleteIndex]);
            // Reset array keys
            $registeredPets = array_values($registeredPets);
            // Save updated registered pets array back to session
            $_SESSION["registeredPets"] = $registeredPets;
            // Redirect to refresh page after deletion
            header("Location: " . $_SERVER["PHP_SELF"]);
            exit();
        }
    } else {
        // Add new pet to registered pets array
        $newPet = [
            "petName" => $_POST["petName"],
            "petAge" => $_POST["petAge"],
            "ownerName" => $_POST["ownerName"]
        ];
        $registeredPets[] = $newPet;

        // Save updated registered pets array back to session
        $_SESSION["registeredPets"] = $registeredPets;

        // Redirect to same page to refresh the list
        header("Location: " . $_SERVER["PHP_SELF"]);
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Pet Registration</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        table, th, td {
            border: 1px solid #ccc;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        form {
            display: inline; /* Keep forms inline for delete buttons */
        }
        .delete-btn {
            background-color: #f44336;
            color: white;
            border: none;
            padding: 6px 12px;
            cursor: pointer;
            border-radius: 4px;
        }
    </style>
</head>
<body>
    <h1>Pet Registration</h1>
    
    <!-- Registration Form -->
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
        <label for="petName">Pet Name:</label>
        <input type="text" id="petName" name="petName" required>

        <label for="petAge">Pet Age:</label>
        <input type="number" id="petAge" name="petAge" required>

        <label for="ownerName">Owner Name:</label>
        <input type="text" id="ownerName" name="ownerName" required>

        <input type="submit" value="Register Pet">
    </form>
    
    <!-- List of Registered Pets -->
    <h2>Registered Pets</h2>
    <?php if (count($registeredPets) > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>Pet Name</th>
                    <th>Pet Age</th>
                    <th>Owner Name</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($registeredPets as $index => $pet): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($pet["petName"]); ?></td>
                        <td><?php echo htmlspecialchars($pet["petAge"]); ?></td>
                        <td><?php echo htmlspecialchars($pet["ownerName"]); ?></td>
                        <td>
                            <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
                                <input type="hidden" name="deleteIndex" value="<?php echo $index; ?>">
                                <input type="submit" class="delete-btn" value="Delete">
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No pets registered yet.</p>
    <?php endif; ?>
</body>
</html>
